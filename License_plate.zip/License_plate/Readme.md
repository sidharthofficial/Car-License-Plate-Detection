Yolo Automartic license plate dtection model.


# How to utilise this. 